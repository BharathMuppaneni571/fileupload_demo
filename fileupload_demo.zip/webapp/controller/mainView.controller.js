sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"bharath/fileupload/fileupload_demo/libs/read-excel-file.min"
], function (Controller, MessageToast, excelLib) {
	"use strict";

	return Controller.extend("bharath.fileupload.fileupload_demo.controller.mainView", {

		handleUploadPress: function (oEvt) {
			var oFileUploader = this.byId("fileUploader");
			var domRef = oFileUploader.getFocusDomRef();
			var file = domRef.files[0];
			var that = this;
			this.fileName = file.name;
			this.fileType = file.type;
			this.domRef = domRef;
			var fileReader = new FileReader();

			// gets file content
			fileReader.readAsDataURL(file); // ones read done then it will triger filereader.onload()
			fileReader.onload = function (data) {
				that.fileData = data.target.result;
				// debugger;
				if (that.fileName.includes(".xlsx") || that.fileType.includes(".spreadsheet")) {
					// readXlsxFile was coming from read excel library
					readXlsxFile(that.domRef.files[0]).then(function (rows) {
						console.log(rows);
						MessageToast.show("all excel data was logged in console for your reference");
						// `rows` is an array of rows
						// each row being an array of cells.
					});
					MessageToast.show("file uploaded is XLSX");
				} else if (that.fileType.includes("/pdf") || that.fileName.includes(".pdf")) {
					MessageToast.show("file uploaded is pdf");
				} else if (that.fileType.includes("image")) {
					MessageToast.show("This is an IMAGE");
				} else {
					MessageToast.show("File type unknown");
				}
			};
		}
	});
});

// this library reads excel file and converts it to json object  https://github.com/catamphetamine/read-excel-file#json
// One can use any npm CDN service, e.g. unpkg.com or jsdelivr.net

// <script src="https://unpkg.com/read-excel-file@4.x/bundle/read-excel-file.min.js"></script>

// <script>
//   var input = document.getElementById('input')
//   input.addEventListener('change', function() {
//     readXlsxFile(input.files[0]).then(function() {
//       // `rows` is an array of rows
//       // each row being an array of cells.
//     })
//   })
// </script>