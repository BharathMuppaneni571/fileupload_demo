sap.ui.define([
	"bharath/fileupload/fileupload_demo/test/unit/controller/mainView.controller"
], function () {
	"use strict";
});